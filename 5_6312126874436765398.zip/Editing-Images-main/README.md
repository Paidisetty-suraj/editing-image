We can apply various kinds of filters like

1.Gray-scale

2.Blur image

3.Changing background

4.decode some text in image and retrieve-back(Image Steganography)

Link to codepen(find actual working)
https://codepen.io/VinayKenguva/pen/LYxeYMw
